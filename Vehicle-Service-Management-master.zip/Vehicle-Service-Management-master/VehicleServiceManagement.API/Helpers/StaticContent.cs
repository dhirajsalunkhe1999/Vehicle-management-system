﻿namespace VehicleServiceManagement.API.Helpers
{
    public static class StaticContent
    {
       
          
    }
}
