﻿namespace VehicleServiceManagement.API.Models.Account
{
    public class LogIn
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
 