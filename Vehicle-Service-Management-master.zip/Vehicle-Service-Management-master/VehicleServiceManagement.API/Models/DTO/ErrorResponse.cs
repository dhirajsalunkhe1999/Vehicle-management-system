﻿namespace VehicleServiceManagement.API.Models.DTO
{
    public class ErrorResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
